import AsyncStorage from '@react-native-async-storage/async-storage';
import { useState, useEffect, useCallback } from 'react';

export default function useStorage() {
  const [pedidos, setPedidos] = useState([]);
  const [pedidoSelecionado, setPedidoSelecionado] = useState(null);
  const [pedidoAtual, setPedidoAtual] = useState('');
  const [statusAtual, setStatusAtual] = useState('');
  const [valorNota, setValorNota] = useState('');
  const [localEntrega, setLocalEntrega] = useState('');
  const [nomeCliente, setNomeCliente] = useState('');
  const [pago, setPago] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);

  const carregarPedidos = useCallback(async () => {
    try {
      const data = await AsyncStorage.getItem('pedidos');
      let pedidosSalvos = data ? JSON.parse(data) : [];

      // Adiciona ID para pedidos antigos que não têm
      pedidosSalvos = pedidosSalvos.map((pedido) => ({
        ...pedido,
        id: pedido.id || `${Date.now()}-${Math.random()}`,
      }));

      setPedidos(pedidosSalvos);
      await AsyncStorage.setItem('pedidos', JSON.stringify(pedidosSalvos));
    } catch (error) {
      console.error('Erro ao carregar pedidos:', error);
    }
  }, []);

  const salvarPedido = async () => {
    if (!pedidoAtual || pedidoAtual.trim() === '') {
      return 'Digite um pedido antes de salvar.';
    }

    try {
      const novoPedido = {
        id: `${Date.now()}-${Math.random()}`,
        nome: pedidoAtual,
        status: statusAtual || 'Pendente',
        valorNota: valorNota || '0',
        localEntrega: localEntrega || 'Não informado',
        nomeCliente: nomeCliente || 'Não informado',
        pago: pago || false,
      };

      const novosPedidos = [...pedidos, novoPedido];

      await AsyncStorage.setItem('pedidos', JSON.stringify(novosPedidos));
      setPedidos(novosPedidos);
      return null;
    } catch (error) {
      console.error('Erro ao salvar pedido:', error);
      return 'Erro ao salvar pedido';
    }
  };

  function abrirPedido(pedido) {
    setPedidoSelecionado(pedido);
    setModalVisible(true);
  }

  async function handleExcluirPedido() {
    if (!pedidoSelecionado) return;

    try {
      const novosPedidos = pedidos.filter(p => p.id !== pedidoSelecionado.id);
      await AsyncStorage.setItem('pedidos', JSON.stringify(novosPedidos));
      setPedidos(novosPedidos);
      setModalVisible(false);
    } catch (error) {
      console.error('Erro ao excluir pedido:', error);
    }
  }

  // Atualizar um pedido
    async function atualizarPedido(pedidoEditado) {
    try {
      const novosPedidos = pedidos.map(p =>
        p.id === pedidoEditado.id ? pedidoEditado : p
      );
      await AsyncStorage.setItem('pedidos', JSON.stringify(novosPedidos));
      setPedidos(novosPedidos);
    } catch (error) {
      console.error('Erro ao atualizar pedido:', error);
    }
  }
  

  useEffect(() => {
    carregarPedidos();
  }, [carregarPedidos]);

  return {
    pedidos,
    pedidoSelecionado,
    setPedidoSelecionado,
    pedidoAtual,
    setPedidoAtual,
    statusAtual,
    setStatusAtual,
    valorNota,
    setValorNota,
    localEntrega,
    setLocalEntrega,
    nomeCliente,
    setNomeCliente,
    pago,
    setPago,
    modalVisible,
    setModalVisible,
    salvarPedido,
    carregarPedidos,
    abrirPedido,
    handleExcluirPedido,
    atualizarPedido,
  };
}
