import React, { useState } from 'react';
import { View, TextInput, Button, Alert, Modal, Text, TouchableOpacity } from 'react-native';
import { styles } from './styles';
import useStorage from '../../hooks/useStorage';

export function Home() {
  const {
    pedidoAtual, setPedidoAtual,
    statusAtual, setStatusAtual,
    valorNota, setValorNota,
    localEntrega, setLocalEntrega,
    nomeCliente, setNomeCliente,
    pago, setPago,
    salvarPedido
  } = useStorage();

  const [modalStatusVisible, setModalStatusVisible] = useState(false);
  const [modalInfoVisible, setModalInfoVisible] = useState(false);

  function adicionarPedido() {
    if (!pedidoAtual || pedidoAtual.trim() === '') {
      Alert.alert("Erro", "Digite um pedido antes de salvar.");
      return;
    }
    setModalStatusVisible(true);
  }

  function selecionarStatus(status) {
    setStatusAtual(status);
    setModalStatusVisible(false);
    setModalInfoVisible(true);
  }

  async function handleSalvar() {
    const erro = await salvarPedido();
    if (erro) {
      Alert.alert("Erro", erro);
    } else {
      setModalInfoVisible(false);
      Alert.alert("Sucesso", "Pedido salvo com sucesso!");
    }
  }

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input_Name}
        placeholder="Digite o Nome do Pedido"
        value={pedidoAtual}  // Alterando para usar pedidoAtual
        onChangeText={setPedidoAtual}  // Usando setPedidoAtual
      />
      <TouchableOpacity style={styles.button_Box} onPress={adicionarPedido}>
        <Text style={styles.button_Text}>Adicionar Pedido</Text>
      </TouchableOpacity>

      {/* Modal de Status */}
      <Modal visible={modalStatusVisible} animationType="slide" transparent onRequestClose={() => setModalStatusVisible(false)}>
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Escolha o Status do Pedido!</Text>
            <TouchableOpacity style={styles.button_Status} onPress={() => selecionarStatus("Sendo preparado")}>
              <Text style={styles.statusText}>Em Preparação</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.button_Status} onPress={() => selecionarStatus("Em trânsito")}>
              <Text style={styles.statusText}>Em Trânsito</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.button_Status} onPress={() => selecionarStatus("Entregue")}>
              <Text style={styles.statusText}>Entregue</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Modal de Informações */}
      <Modal visible={modalInfoVisible} animationType="slide" transparent onRequestClose={() => setModalInfoVisible(false)}>
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Preencha as Informações do Pedido!</Text>
            <TextInput style={styles.input} placeholder="Nome do Cliente" value={nomeCliente} onChangeText={setNomeCliente} />
            <TextInput style={styles.input} placeholder="Local de Entrega" value={localEntrega} onChangeText={setLocalEntrega} />
            <TextInput style={styles.input} placeholder="Valor da Nota (R$)" keyboardType="numeric" value={valorNota} onChangeText={setValorNota} />
            <TouchableOpacity style={[styles.statusButton, { backgroundColor: pago ? 'green' : 'red' }]} onPress={() => setPago(!pago)}>
              <Text style={styles.statusText}>{pago ? "Pagamento efetuado" : "Pagamento Não efetuado"}</Text>
            </TouchableOpacity>
            <Button title="Salvar Pedido" onPress={handleSalvar} />
          </View>
        </View>
      </Modal>
    </View>
  );
}
