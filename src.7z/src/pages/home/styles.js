import { StyleSheet } from "react-native";



export const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
    },
    // --------------------------   HOME  -------------------------
    input_Name: {
        width: '80%',
        height: 40,
        borderColor: '#ccc',
        borderWidth: 1,
        marginBottom: 10,
        paddingHorizontal: 10,
        borderRadius: 20,  // -- Arrendodamento de Cantos do Imput
        textAlign: "center",
    },


    button_Box:{
        width: '30%',
        height: 50,
        borderColor: '#ccc',
        padding: 10,
        backgroundColor: 'green',
        borderWidth: 1,
        lineHeight: 'auto', // Lembre-se disso
        borderRadius: 20,

    },

    button_Text:{
        textAlign: "center",
    },

      //----------------------------------------------------------------

    input: {
        width: '90%',
        height: 40,
        borderColor: '#ccc',
        borderWidth: 1,
        marginBottom: 10,
        paddingHorizontal: 10,
        borderRadius: 20,
    },
    modalContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
    },
    modalContent: {
        backgroundColor: '#fff',
        padding: 20,
        borderRadius: 10,
        alignItems: 'center',
        width: '80%',
    },
    modalTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 10,
    },
    button_Status: {
        backgroundColor: '#007bff',
        padding: 10,
        marginVertical: 5,
        width: 'auto',
        alignItems: 'center',
        borderRadius: 20,
    },
    statusText: {
        color: '#fff',
        fontSize: 16,
    },
});
